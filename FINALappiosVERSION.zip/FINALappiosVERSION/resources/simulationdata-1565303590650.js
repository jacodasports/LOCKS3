function initData() {
  jimData.variables["NFL WEST"] = "";
  jimData.variables["FirstandLastName"] = "";
  jimData.variables["Username"] = "";
  jimData.variables["VEGAS"] = "1";
  jimData.variables["DETROIT"] = "1";
  jimData.variables["CHICAGO"] = "A";
  jimData.variables["NFL TEAMS"] = "";
  jimData.variables["email"] = "";
  jimData.variables["MIAMI"] = "";
  jimData.variables["DALLAS"] = "";
  jimData.variables["Password"] = "";
  jimData.datamasters["LEADERBOARD"] = [
    {
      "id": 1,
      "datamaster": "LEADERBOARD",
      "userdata": {
        "RANK": "2",
        "USERNAME": "XAMPLE1",
        "POINTS": "1200",
        "%": "75.0"
      }
    },
    {
      "id": 2,
      "datamaster": "LEADERBOARD",
      "userdata": {
        "RANK": "3",
        "USERNAME": "XAMPLE3",
        "POINTS": "1100",
        "%": "68.8"
      }
    },
    {
      "id": 3,
      "datamaster": "LEADERBOARD",
      "userdata": {
        "RANK": "1",
        "USERNAME": "XAMPLE2",
        "POINTS": "1400",
        "%": "87.5"
      }
    },
    {
      "id": 4,
      "datamaster": "LEADERBOARD",
      "userdata": {
        "RANK": "4",
        "USERNAME": "XAMPLE4",
        "POINTS": "800",
        "%": "50.0"
      }
    }
  ];

  jimData.datamasters["Player Database"] = [
    {
      "id": 1,
      "datamaster": "Player Database",
      "userdata": {
        "FirstandLastName": "CocoD",
        "Email": "Coco@gmail.com",
        "Username": "CocoD",
        "Password": "Jasmine1"
      }
    },
    {
      "id": 2,
      "datamaster": "Player Database",
      "userdata": {
        "FirstandLastName": "AthD",
        "Email": "ath@gmail.com",
        "Username": "AthD",
        "Password": "AD219"
      }
    }
  ];

  jimData.datamasters["PLAYERS"] = [
    {
      "id": 1,
      "datamaster": "PLAYERS",
      "userdata": {
        "Username": "Cenkali219",
        "Password": "Athena219"
      }
    },
    {
      "id": 2,
      "datamaster": "PLAYERS",
      "userdata": {
        "Username": "Admin",
        "Password": "xx1234"
      }
    }
  ];

  jimData.isInitialized = true;
}